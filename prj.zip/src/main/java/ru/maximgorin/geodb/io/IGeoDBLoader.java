package ru.maximgorin.geodb.io;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import ru.maximgorin.geodb.GeoDBException;
import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;
/**
 * Interface to load/import data from a file
 * @author Maksim_Gorin
 *
 */
public interface IGeoDBLoader {
	/**
	 * Loads data from a file
	 * @param name the name of the file
	 * @param db the database
	 * @throws IOException, if an error of IO is occured
	 * @throws GeoDBException if an error is occured
	 */
	void load(String name, IGeoDB db) throws IOException, GeoDBException;
	/**
	 * Loads data from a file
	 * @param f the file with data to be loaded
	 * @param db the database
	 * @throws IOException, if an error of IO is occured
	 * @throws GeoDBException if an error is occured
	 */
	void load(File f, IGeoDB db) throws IOException, GeoDBException;
}
