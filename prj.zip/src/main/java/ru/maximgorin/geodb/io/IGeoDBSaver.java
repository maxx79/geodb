package ru.maximgorin.geodb.io;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;
/**
 * The interface is to save/export data from the database 
 * @author Maksim_Gorin
 *
 */
public interface IGeoDBSaver {
	/**
	 * Saves all data into a file
	 * @param name the name of the file
	 * @param db the database with data
	 * @throws IOException if an error of IO is occured
	 */
	void save(String name, IGeoDB db) throws IOException;
	/**
	 * Saves all data into a file
	 * @param f the path to the file
	 * @param db the database with data
	 * @throws IOException if an error of IO is occured
	 */
	void save(File f, IGeoDB db) throws IOException;
}
