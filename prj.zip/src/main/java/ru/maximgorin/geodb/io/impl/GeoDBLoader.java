package ru.maximgorin.geodb.io.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Logger;

import ru.maximgorin.geodb.GeoDBException;
import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.io.IGeoDBLoader;
import ru.maximgorin.geodb.parser.GeoCoordParser;
import ru.maximgorin.geodb.parser.IGeoCoordParser;
import ru.maximgorin.geodb.parser.ParserException;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public final class GeoDBLoader implements IGeoDBLoader {
	private final static Logger LOG = Logger.getLogger(GeoDBLoader.class.getName());
	private final static GeoDBLoader instance = new GeoDBLoader();

	private GeoDBLoader() {

	}

	public final static IGeoDBLoader getInstance() {
		return instance;
	}

	@Override
	public void load(String name, IGeoDB db) throws IOException, GeoDBException {
		if (name == null || name.trim().isEmpty()) {
			throw new IllegalArgumentException("name is null or empty");
		}
		load(new File(name), db);

	}

	@Override
	public void load(File f, IGeoDB db) throws IOException, GeoDBException {
		if (f == null) {
			throw new IllegalArgumentException("f is null");
		}
		if (db == null) {
			throw new IllegalArgumentException("db is null");
		}
		try (FileInputStream fis = new FileInputStream(f)) {
			db.clear();
			IGeoCoordParser parser = GeoCoordParser.getInstance();
			try {
				Map<Identifier, Shape> map = parser.parse(fis);
				for (Map.Entry<Identifier, Shape> entry : map.entrySet()) {
					db.createShape(entry.getKey(), entry.getValue());
				}
			} catch (ParserException e) {
				throw new GeoDBException(e);
			}

		}
	}
}
