package ru.maximgorin.geodb.io.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.logging.Logger;

import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.io.IGeoDBSaver;
import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public final class GeoDBSaver implements IGeoDBSaver {
	private final static Logger LOG = Logger.getLogger(GeoDBSaver.class.getName());
	private final static GeoDBSaver instance = new GeoDBSaver();

	private GeoDBSaver() {

	}

	@Override
	public void save(String name, IGeoDB db) throws IOException {
		if (name == null || name.trim().isEmpty()) {
			throw new IllegalArgumentException("name is null or empty");
		}
		save(new File(name), db);
	}

	@Override
	public void save(File f, IGeoDB db) throws IOException {
		if (f == null) {
			throw new IllegalArgumentException("f is null");
		}
		if (db == null) {
			throw new IllegalArgumentException("db is null");
		}
		StringBuilder sb = new StringBuilder();
		try (FileOutputStream fos = new FileOutputStream(f)) {
			Collection<Identifier> ids = db.identifiers();
			for (Identifier id : ids) {
				sb.setLength(0);
				sb.append(id.getValue()).append("|");
				Shape sh = db.getShape(id);
				Collection<Point> pts = sh.getPoints();
				int i = 0;
				for (Point pt : pts) {
					sb.append(pt.getX()).append(",").append(pt.getY());
					sb.append(++i < pts.size() ? ";" : System.lineSeparator());
				}
				fos.write(sb.toString().getBytes());
			}
		}
	}

	public final static IGeoDBSaver getInstance() {
		return instance;
	}
}
