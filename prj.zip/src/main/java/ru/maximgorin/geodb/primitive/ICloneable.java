package ru.maximgorin.geodb.primitive;

public interface ICloneable<T> {
	public T copy();
}
