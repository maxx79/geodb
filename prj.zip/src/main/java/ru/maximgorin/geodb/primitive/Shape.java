package ru.maximgorin.geodb.primitive;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

//This class is not thread-safe
public class Shape implements ICloneable<Shape> {
	private final List<Point> points = new LinkedList<>();

	public Shape() {
	}

	public Shape(Shape sh) {
		if (sh == null) {
			throw new IllegalArgumentException("sh is null");
		}
		for (Point pt : sh.points) {
			points.add(pt.copy());
		}
	}

	public Shape(Collection<Point> col) {
		setPoints(col);
	}

	public void setPoints(Collection<Point> col) {
		if (col == null) {
			throw new IllegalArgumentException("col is null");
		}
		if (col.size() < 3) {
			throw new IllegalArgumentException("Shape must have at least 3 points");
		}
		if (col.size() > 7) {
			throw new IllegalArgumentException("Shape must have at most 7 points");
		}
		for (Point pt : col) {
			points.add(pt.copy());
		}
	}

	public Collection<Point> getPoints() {
		List<Point> list = new ArrayList<>(points.size());
		for (Point pt : points) {
			list.add(pt.copy());
		}
		return list;
	}

	public boolean isEmpty() {
		return points.isEmpty();
	}

	public int getPointCount() {
		return points.size();
	}

	public boolean remove(Point p) {
		if (points.contains(p) && points.size() == 3) {
			throw new IllegalArgumentException("Shape must contain at least 3 points");
		}
		return points.remove(p);
	}

	public Point remove(int i) {
		if (i < 0) {
			throw new IllegalArgumentException("index is negative");
		}
		if (i >= points.size()) {
			throw new IllegalArgumentException("index is out of range");
		}
		if (points.size() == 3) {
			throw new IllegalArgumentException("Shape must contain at least 3 points");
		}
		return points.remove(i);
	}

	public void add(Point p) {
		if (p == null) {
			throw new IllegalArgumentException("p is null");
		}
		if (points.contains(p)) {
			throw new IllegalArgumentException("Shape is already the same point");
		}
		if (points.size() == 7) {
			throw new IllegalArgumentException("Shape must contain at most 7 points");
		}
		points.add(p.copy());
	}

	public void addAll(Collection<Point> pts) {
		if (pts == null || pts.isEmpty()) {
			throw new IllegalArgumentException("Point array is  null or empty");
		}
		for (Point p : pts) {
			add(p);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((points == null) ? 0 : points.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Shape other = (Shape) obj;
		if (points == null) {
			if (other.points != null)
				return false;
		} else if (!points.equals(other.points))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Shape [points=" + points + "]";
	}

	@Override
	public Shape copy() {
		return new Shape(this);
	}

}
