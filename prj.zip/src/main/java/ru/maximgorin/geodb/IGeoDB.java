package ru.maximgorin.geodb;

import java.util.Collection;

import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

/**
 * The interface is to work with data of database
 * 
 * @author Maksim_Gorin
 *
 */
public interface IGeoDB {
	/**
	 * Add a point into a shape.
	 * @param id an identifier of the shape
	 * @param pt point, to needed to be added into the shape
	 * @return true, if the point is added, otherwise - false
	 * @throws GeoDBException - if an error is occurred
	 */
	public boolean addPoint(Identifier id, Collection<Point> pt) throws GeoDBException;

	/**
	 * Deletes a point by index 
	 * @param id  an identifier of shape
	 * @param index index of point
	 * @return true, if the point is deleted, otherwise - false
	 * @throws GeoDBException, if an error is occurred
	 */
	public boolean deletePoint(Identifier id, int index) throws GeoDBException;
	/**
	 * Checks, exists a shape by id or doesn't
	 * @param id  an identifier of the shape
	 * @return true - the shape exists, otherwise - false
	 */
	public boolean containsShape(Identifier id);
	/**
	 * Adds a shape into the database
	 * @param id  an identifier of the shape
	 * @param shape - the shape is to be added
	 * @throws GeoDBException - if an error is occurred
	 */
	public void createShape(Identifier id, Shape shape) throws GeoDBException;
	/**
	 * Deletes a shape from the database
	 * @param id  an identifier of shape
	 * @return true, if the shape is deleted, otherwise- false
	 * @throws GeoDBException - if an error is occurred
	 */
	public boolean deleteShape(Identifier id) throws GeoDBException;
	/**
	 * Returns a collection of identifiers
	 * @return collection of identifiers
	 */
	public Collection<Identifier> identifiers();
	/**
	 * Returns an instance of shape
	 * @param id an identifier of shape
	 * @return a shape if it is found, otherwise - null
	 */
	public Shape getShape(Identifier id);
	/**
	 * Checks if the database has content
	 * @return true - if the database is not empty, otherwise - false
	 */
	public boolean isEmpty();
	/**
	 * Removes all data from the database
	 */
	public void clear();
	
	/**
	 * Returns number of shapes
	 * @param pointCount
	 * @return
	 */
	public Collection<Integer> shapeCountList();

}
