package ru.maximgorin.geodb.operation.io.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import ru.maximgorin.geodb.operation.Command;
import ru.maximgorin.geodb.operation.GeoDBOperation;
import ru.maximgorin.geodb.operation.GeoDBOperationException;
import ru.maximgorin.geodb.operation.io.IGeoDBOperationParser;
import ru.maximgorin.geodb.parser.ParserException;
import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.type.Identifier;

public class GeoDBOperationParser implements IGeoDBOperationParser {
	private final static GeoDBOperationParser instance = new GeoDBOperationParser();

	private GeoDBOperationParser() {
	}

	private static String createMessage(int lineNumber, String message) {
		return "[" + lineNumber + "] " + message;
	}

	@Override
	public Collection<GeoDBOperation> load(String name) throws IOException, GeoDBOperationException {
		if (name == null || name.trim().isEmpty()) {
			throw new IllegalArgumentException("name is null or empty");
		}
		return load(new File(name));
	}

	@Override
	public Collection<GeoDBOperation> load(File f) throws IOException, GeoDBOperationException {
		List<GeoDBOperation> list = new LinkedList<>();
		try (FileInputStream fis = new FileInputStream(f)) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
			String line;
			int lineNumber = 0;
			while ((line = reader.readLine()) != null) {
				if (line.trim().isEmpty()) {
					throw new GeoDBOperationException(createMessage(lineNumber, "Empty line!"));
				}
				try {
					list.add(parse(lineNumber, line));
				} catch (RuntimeException e) {
					throw new GeoDBOperationException(createMessage(lineNumber, e.getMessage()), e);
				}
			}
		}
		return list;
	}

	private GeoDBOperation parse(int lineNumber, String line) throws GeoDBOperationException {
		String parts[] = line.split("\\|");
		if (parts.length < 2) {
			throw new GeoDBOperationException(createMessage(lineNumber, "Bad format!"));
		}
		Command command = Command.fromString(parts[0].trim());
		if (command == null) {
			throw new GeoDBOperationException(createMessage(lineNumber, "Command is not found!"));
		}
		Identifier identifier = new Identifier(parts[1].trim());
		if (command == Command.CreateShape) {
			if (parts.length < 3) {
				throw new GeoDBOperationException(createMessage(lineNumber, "Point array is expected!"));
			}
			return new GeoDBOperation(command, identifier, parsePoints(parts[2].trim()));
		} else if (command == Command.AddPoint) {
			if (parts.length < 3) {
				throw new GeoDBOperationException(createMessage(lineNumber, "Point is expected!"));
			}
			return new GeoDBOperation(command, identifier, parsePoint(parts[2].trim()));

		} else if (command == Command.DeletePoint) {
			if (parts.length < 3) {
				throw new GeoDBOperationException(createMessage(lineNumber, "Index is expected!"));
			}
			return new GeoDBOperation(command, identifier, parseIndex(parts[2].trim()));
		}
		return new GeoDBOperation(command, identifier);
	}

	private int parseIndex(String line) {
		return Integer.parseInt(line);
	}

	private Collection<Point> parsePoint(String line) {
		List<Point> list = new ArrayList<>();
		String parts[] = line.split(",");
		list.add(new Point(Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())));
		return list;
	}

	private Collection<Point> parsePoints(String line) {
		String parts[] = line.split(";");
		if (parts.length < 3) {
			throw new IllegalArgumentException("Bad number of points. Expected at least three");
		}
		List<Point> list = new ArrayList<>();
		for (String part : parts) {
			list.addAll(parsePoint(part.trim()));
		}
		return list;
	}

	public final static IGeoDBOperationParser getInstance() {
		return instance;
	}

}
