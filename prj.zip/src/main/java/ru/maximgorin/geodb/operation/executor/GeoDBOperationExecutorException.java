package ru.maximgorin.geodb.operation.executor;

public class GeoDBOperationExecutorException extends Exception {

	public GeoDBOperationExecutorException() {

	}

	public GeoDBOperationExecutorException(String message) {
		super(message);

	}

	public GeoDBOperationExecutorException(Throwable t) {
		super(t);
	}

	public GeoDBOperationExecutorException(String message, Throwable t) {
		super(message, t);

	}
}
