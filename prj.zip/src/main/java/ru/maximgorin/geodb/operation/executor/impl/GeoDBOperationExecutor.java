package ru.maximgorin.geodb.operation.executor.impl;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import ru.maximgorin.geodb.GeoDBException;
import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.operation.Command;
import ru.maximgorin.geodb.operation.GeoDBOperation;
import ru.maximgorin.geodb.operation.executor.GeoDBOperationExecutorException;
import ru.maximgorin.geodb.operation.executor.IGeoDBOperationExecutor;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public final class GeoDBOperationExecutor implements IGeoDBOperationExecutor {
	private final static Logger LOG = Logger.getLogger(GeoDBOperationExecutor.class.getName());
	private final static IGeoDBOperationExecutor instance = new GeoDBOperationExecutor();

	private GeoDBOperationExecutor() {

	}

	private static GeoDBOperationExecutorException createException(Identifier id, Command cmd, GeoDBException ex) {
		String message = "Command=" + cmd + ", id=" + id + ", msg=" + ex.getMessage();
		return new GeoDBOperationExecutorException(message, ex);

	}

	@Override
	public Collection<Exception> execute(IGeoDB db, Collection<GeoDBOperation> ops)
			throws GeoDBOperationExecutorException {
		if (db == null) {
			throw new IllegalArgumentException("db is null");
		}
		if (ops == null) {
			throw new IllegalArgumentException("ops is null");
		}
		List<Exception> exceptions = new LinkedList<>();
		for (GeoDBOperation op : ops) {
			if (op.getCommand() == Command.CreateShape) {
				try {
					db.createShape(op.getId(), new Shape(op.getPoints()));
				} catch (GeoDBException e) {
					exceptions.add(createException(op.getId(), op.getCommand(), e));
				}
			} else if (op.getCommand() == Command.DeleteShape) {
				try {
					db.deleteShape(op.getId());
				} catch (GeoDBException e) {
					exceptions.add(createException(op.getId(), op.getCommand(), e));
				}
			} else if (op.getCommand() == Command.DeletePoint) {
				try {
					db.deletePoint(op.getId(), op.getIndex());
				} catch (GeoDBException e) {
					exceptions.add(createException(op.getId(), op.getCommand(), e));
				}
			} else if (op.getCommand() == Command.AddPoint) {
				try {
					db.addPoint(op.getId(), op.getPoints());
				} catch (GeoDBException e) {
					exceptions.add(createException(op.getId(), op.getCommand(), e));
				}
			}
		}
		return exceptions;

	}

	public final static IGeoDBOperationExecutor getInstance() {
		return instance;
	}
}
