package ru.maximgorin.geodb.operation;

public enum Command {
	CreateShape("create-shape"), DeleteShape("delete-shape"), AddPoint("add-point"), DeletePoint("delete-point");
	private final String code;

	Command(String code) {
		this.code = code;
	}

	String getCode() {
		return code;
	}

	public static Command fromString(String code) {
		for (Command c : Command.values()) {
			if (c.code.equalsIgnoreCase(code)) {
				return c;
			}
		}
		return null;
	}
}
