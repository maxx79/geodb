package ru.maximgorin.geodb.operation;

public class GeoDBOperationException extends Exception {

	public GeoDBOperationException() {
	}

	public GeoDBOperationException(String message) {
		super(message);
	}

	public GeoDBOperationException(Throwable t) {
		super(t);
	}

	public GeoDBOperationException(String message, Throwable t) {
		super(message, t);
	}

}
