package ru.maximgorin.geodb.operation.executor;

import java.util.Collection;

import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.operation.GeoDBOperation;
/**
 * Executes a sequence of operations with a database
 * @author Maksim_Gorin
 *
 */
public interface IGeoDBOperationExecutor {
	/**
	 * Executes operations with the database
	 * @param db, the database
	 * @param ops, a collection of operations
	 * @return a collection of occurred exceptions in process of execution
	 * @throws GeoDBOperationExecutorException, if an error is occurred
	 */
	public Collection<Exception> execute(IGeoDB db, Collection<GeoDBOperation> ops) throws GeoDBOperationExecutorException;
}
