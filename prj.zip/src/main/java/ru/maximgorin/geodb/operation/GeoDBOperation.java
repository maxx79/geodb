package ru.maximgorin.geodb.operation;

import java.util.Collection;

import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.type.Identifier;

public class GeoDBOperation {
	private Command command;
	private Identifier id;
	private Collection<Point> points;
	private int index = -1;

	public GeoDBOperation(Command command, Identifier id) {
		if (command != Command.DeleteShape) {
			throw new IllegalArgumentException("delete-shape command is expected");
		}
		setCommand(command);
		setId(id);
	}

	public GeoDBOperation(Command command, Identifier id, Collection<Point> points) {
		if (command != Command.CreateShape && command != Command.AddPoint) {
			throw new IllegalArgumentException("Bad combination of command and points");
		}
		setCommand(command);
		setId(id);
		setPoints(points);
	}

	public GeoDBOperation(Command command, Identifier id, int index) {
		if (command != Command.DeletePoint) {
			throw new IllegalArgumentException("Bad combination of command and index of point");
		}
		setCommand(command);
		setId(id);
		setIndex(index);
	}

	public Command getCommand() {
		return command;
	}

	protected void setCommand(Command command) {
		if (command == null) {
			throw new IllegalArgumentException("Command is null");
		}
		this.command = command;
	}

	public Identifier getId() {
		return id;
	}

	protected void setId(Identifier id) {
		if (id == null) {
			throw new IllegalArgumentException("id is null");
		}
		this.id = id;
	}

	public Collection<Point> getPoints() {
		return points;
	}

	protected void setPoints(Collection<Point> points) {
		if (points == null || points.isEmpty()) {
			throw new IllegalArgumentException("points is null or empty");
		}
		this.points = points;
	}

	public int getIndex() {
		return index;
	}

	protected void setIndex(int index) {
		this.index = index;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((command == null) ? 0 : command.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + index;
		result = prime * result + ((points == null) ? 0 : points.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GeoDBOperation other = (GeoDBOperation) obj;
		if (command != other.command)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (index != other.index)
			return false;
		if (points == null) {
			if (other.points != null)
				return false;
		} else if (!points.equals(other.points))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "GeoDBAction [command=" + command + ", id=" + id + ", points=" + points + ", index=" + index + "]";
	}

}
