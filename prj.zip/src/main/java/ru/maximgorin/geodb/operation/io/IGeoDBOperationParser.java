package ru.maximgorin.geodb.operation.io;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.operation.GeoDBOperation;
import ru.maximgorin.geodb.operation.GeoDBOperationException;
/**
 * The interface is to load operations with the database from a file
 * @author Maksim_Gorin
 *
 */
public interface IGeoDBOperationParser {
	/**
	 * Loads operations with the database from a file
	 * @param name, the name of file
	 * @return Collection of operations
	 * @throws IOException, if an error of IO is occured
	 * @throws GeoDBOperationException if an error is occured
	 */
	public Collection<GeoDBOperation> load(String name) throws IOException, GeoDBOperationException;
	/**
	 * Loads operations with the database from a file
	 * @param f, the path to a file
	 * @return Collection of operations
	 * @throws IOException, if an error of IO is occured
	 * @throws GeoDBOperationException if an error is occured
	 */
	public Collection<GeoDBOperation> load(File f) throws IOException, GeoDBOperationException;
}
