package ru.maximgorin.geodb.type;

import java.util.UUID;

import ru.maximgorin.geodb.primitive.ICloneable;

public class Identifier implements ICloneable<Identifier> {
	private String value = UUID.randomUUID().toString();

	public Identifier() {

	}

	public Identifier(String value) {
		setValue(value);
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		if (value == null || value.trim().isEmpty()) {
			throw new IllegalArgumentException("value is null or empty");
		}
		this.value = value;
	}

	@Override
	public Identifier copy() {
		return new Identifier(value);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Identifier other = (Identifier) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Identifier [value=" + value + "]";
	}

}
