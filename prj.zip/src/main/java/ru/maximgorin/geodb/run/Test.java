package ru.maximgorin.geodb.run;

import java.io.IOException;

import ru.maximgorin.geodb.GeoDBException;
import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.impl.GeoDB;
import ru.maximgorin.geodb.io.IGeoDBLoader;
import ru.maximgorin.geodb.io.IGeoDBSaver;
import ru.maximgorin.geodb.io.impl.GeoDBLoader;
import ru.maximgorin.geodb.io.impl.GeoDBSaver;

public class Test {

	public static void main(String[] args) throws IOException, GeoDBException {
		IGeoDBLoader loader = GeoDBLoader.getInstance();
		IGeoDBSaver saver = GeoDBSaver.getInstance();
		IGeoDB db1 = new GeoDB();
		IGeoDB db2 = new GeoDB();
		loader.load("shapes.db", db1);
		saver.save("shapes2.db", db1);
		loader.load("shapes2.db", db2);
		System.out.println("Db1=Db2: "+db1.equals(db2));

	}

}
