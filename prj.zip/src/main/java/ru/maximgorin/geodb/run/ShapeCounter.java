package ru.maximgorin.geodb.run;

class ShapeCounter {
	private int counter;

	ShapeCounter() {

	}

	ShapeCounter(int counter) {
		setCounter(counter);
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public int inc() {
		return ++counter;
	}

	public int dec() {
		return --counter;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + counter;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShapeCounter other = (ShapeCounter) obj;
		if (counter != other.counter)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ShapeCounter [counter=" + counter + "]";
	}
	
}
