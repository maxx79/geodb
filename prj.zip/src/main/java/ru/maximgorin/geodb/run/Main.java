package ru.maximgorin.geodb.run;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.impl.GeoDB;
import ru.maximgorin.geodb.io.IGeoDBLoader;
import ru.maximgorin.geodb.io.IGeoDBSaver;
import ru.maximgorin.geodb.io.impl.GeoDBLoader;
import ru.maximgorin.geodb.io.impl.GeoDBSaver;
import ru.maximgorin.geodb.operation.GeoDBOperation;
import ru.maximgorin.geodb.operation.executor.IGeoDBOperationExecutor;
import ru.maximgorin.geodb.operation.executor.impl.GeoDBOperationExecutor;
import ru.maximgorin.geodb.operation.io.IGeoDBOperationParser;
import ru.maximgorin.geodb.operation.io.impl.GeoDBOperationParser;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public class Main {
	private final static Logger LOG = Logger.getLogger(Main.class.getName());

	private static void printShapesCounter(IGeoDB db) {
		for (Integer i : db.shapeCountList()) {
			LOG.info(i + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		try {
			IGeoDBLoader loader = GeoDBLoader.getInstance();
			IGeoDBSaver saver = GeoDBSaver.getInstance();
			IGeoDB db = new GeoDB();
			loader.load("shapes.db", db);
			printShapesCounter(db);
			IGeoDBOperationParser operSaver = GeoDBOperationParser.getInstance();
			Collection<GeoDBOperation> opers = operSaver.load("operations.data");
			IGeoDBOperationExecutor executor = GeoDBOperationExecutor.getInstance();
			Collection<Exception> errors = executor.execute(db, opers);
			LOG.info("Total operations:" + opers.size());
			LOG.info("Successful executed: " + (opers.size() - errors.size()));
			LOG.info("Errors occurred:" + errors.size());
			LOG.info("Errors detailed:");
			for (Exception e : errors) {
				LOG.info(e.getMessage());
			}
			printShapesCounter(db);
			saver.save("updated.db", db);

		} catch (Exception e) {
			LOG.throwing(Main.class.getName(), "main()", e);
		}

	}

}
