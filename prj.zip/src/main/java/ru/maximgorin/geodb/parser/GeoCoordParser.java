package ru.maximgorin.geodb.parser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public final class GeoCoordParser implements IGeoCoordParser {
	private final static GeoCoordParser instance = new GeoCoordParser();

	private GeoCoordParser() {

	}

	private static String createMessage(int lineNumber, String message) {
		return "[" + lineNumber + "] " + message;
	}

	@Override
	public Map<Identifier, Shape> parse(InputStream in) throws ParserException, IOException {
		if (in == null) {
			throw new IllegalArgumentException("in is null");
		}
		Map<Identifier, Shape> map = new HashMap<>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		String line;
		int lineNumber = 0;
		while ((line = reader.readLine()) != null) {
			if (line.trim().isEmpty()) {
				throw new ParserException(createMessage(lineNumber, "Empty line!"));
			}
			lineNumber++;
			parseLine(line, map, lineNumber);
		}
		return map;
	}

	private void parseLine(String line, Map<Identifier, Shape> map, int lineNumber) throws ParserException {

		String splitted[] = line.split("\\|");
		if (splitted.length != 2) {
			throw new ParserException(createMessage(lineNumber, "Delimiter '|' not found!"));
		}
		Identifier id = new Identifier(splitted[0].trim());
		String pairs[] = splitted[1].split(";");
		if (pairs.length < 3) {
			throw new ParserException(createMessage(lineNumber, "Number of point not must be less three"));
		}
		Collection<Point> points = parsePoints(pairs, lineNumber);
		map.put(id, new Shape(points));
	}

	private Collection<Point> parsePoints(String[] pairs, int lineNumber) throws ParserException {
		List<Point> list = new LinkedList<>();
		for (String pair : pairs) {
			String coords[] = pair.split(",");
			if (coords.length != 2) {
				throw new ParserException(createMessage(lineNumber, "Invalid number of coordinates!"));
			}
			Point pt = new Point(Integer.parseInt(coords[0].trim()), Integer.parseInt(coords[1].trim()));
			list.add(pt);
		}
		return list;
	}

	public final static IGeoCoordParser getInstance() {
		return instance;
	}
}
