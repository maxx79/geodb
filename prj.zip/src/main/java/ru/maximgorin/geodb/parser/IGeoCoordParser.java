package ru.maximgorin.geodb.parser;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

public interface IGeoCoordParser {
	/**
	 * Parses text data from InputStream
	 * @param is  InputStream with data
	 * @return The map class with identifiers associated with shapes
	 * @throws ParserException, if an error of parsing is occured
	 * @throws IOException if an error of IO is occured
	 */
	public Map<Identifier, Shape> parse(InputStream is) throws ParserException, IOException;
}
