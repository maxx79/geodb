package ru.maximgorin.geodb.parser;

public class ParserException extends Exception {

	public ParserException() {
		super();
	}

	public ParserException(String message, Throwable t) {
		super(message, t);
	}

	public ParserException(String message) {
		super(message);
	}

	public ParserException(Throwable t) {
		super(t);
	}

}
