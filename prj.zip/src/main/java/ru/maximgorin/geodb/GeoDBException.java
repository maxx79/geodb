package ru.maximgorin.geodb;

public class GeoDBException extends Exception {

	public GeoDBException() {
		super();
	}

	public GeoDBException(String message, Throwable t) {
		super(message, t);
	}

	public GeoDBException(String message) {
		super(message);
	}

	public GeoDBException(Throwable t) {
		super(t);
	}

}
