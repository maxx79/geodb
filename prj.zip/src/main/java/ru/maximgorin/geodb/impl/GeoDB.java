package ru.maximgorin.geodb.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Logger;

import ru.maximgorin.geodb.GeoDBException;
import ru.maximgorin.geodb.IGeoDB;
import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.primitive.Shape;
import ru.maximgorin.geodb.type.Identifier;

/**
 * 
 * @author Maksim_Gorin 
 * Implements the database functionality in memory. It can
 *         work in multithread enviroment
 */
public class GeoDB implements IGeoDB {
	private final static Logger LOG = Logger.getLogger(GeoDB.class.getName());
	private final Map<Identifier, Shape> map = new LinkedHashMap<>();

	@Override
	public boolean addPoint(Identifier id, Collection<Point> pts) throws GeoDBException {
		if (id == null) {
			throw new GeoDBException("id is null");
		}
		if (pts == null || pts.isEmpty()) {
			throw new GeoDBException("point array is null or empty");
		}
		synchronized (map) {
			Shape sh = map.get(id);
			if (sh == null) {
				return false;
			}
			try {
				sh.addAll(pts);
			} catch (RuntimeException e) {
				throw new GeoDBException(e);
			}
		}
		return true;
	}

	@Override
	public boolean deletePoint(Identifier id, int index) throws GeoDBException {
		if (id == null) {
			throw new GeoDBException("id is null");
		}
		if (index == -1) {
			throw new IllegalArgumentException("index is negative");
		}
		synchronized (map) {
			try {
				Shape sh = map.get(id);
				if (sh == null) {
					return false;
				}
				sh.remove(index);
			} catch (RuntimeException e) {
				throw new GeoDBException(e);
			}
		}
		return true;
	}

	@Override
	public boolean containsShape(Identifier id) {
		if (id == null) {
			return false;
		}
		synchronized (map) {
			return map.containsKey(id);
		}
	}

	@Override
	public void createShape(Identifier id, Shape sh) throws GeoDBException {
		if (id == null) {
			throw new IllegalArgumentException("id is null");
		}
		if (sh == null) {
			throw new IllegalArgumentException("point array is null or empty");
		}
		try {
			synchronized (map) {
				if (map.containsKey(id)) {
					throw new GeoDBException("shape already exists");
				}
				map.put(id.copy(), sh.copy());
			}
		} catch (RuntimeException e) {
			throw new GeoDBException(e);
		}
	}

	@Override
	public boolean deleteShape(Identifier id) throws GeoDBException {
		if (id == null) {
			return false;
		}
		Shape deletedSh = null;
		synchronized (map) {
			deletedSh = map.remove(id);
		}
		return deletedSh != null;
	}

	@Override
	public Collection<Identifier> identifiers() {
		synchronized (map) {
			if (map.isEmpty()) {
				return Collections.emptyList();
			}
			Set<Identifier> keySet = map.keySet();
			List<Identifier> list = new ArrayList<>(keySet.size());
			for (Identifier id : keySet) {
				list.add(id.copy());
			}
			return list;
		}
	}

	@Override
	public Shape getShape(Identifier id) {
		if (id == null) {
			return null;
		}
		Shape sh;
		synchronized (map) {
			sh = map.get(id);
		}
		return sh == null ? null : sh.copy();
	}

	@Override
	public boolean isEmpty() {
		synchronized (map) {
			return map.isEmpty();
		}
	}

	@Override
	public void clear() {
		synchronized (map) {
			map.clear();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((map == null) ? 0 : map.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GeoDB other = (GeoDB) obj;
		if (other.map.size() != map.size()) {
			return false;
		}
		for (Map.Entry<Identifier, Shape> entry : map.entrySet()) {
			Shape sh = other.getShape(entry.getKey());
			if (!entry.getValue().equals(sh)) {
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		return "GeoDB [map=" + map + "]";
	}

	@Override
	public Collection<Integer> shapeCountList() {
		Map<Integer, Integer> countMap = new TreeMap<>();
		synchronized (map) {
			for (Shape sh : map.values()) {
				Integer count = countMap.get(sh.getPointCount());
				if (count == null) {
					count = Integer.valueOf(0);
				}
				count++;
				countMap.put(sh.getPointCount(), count);
			}
		}
		return countMap.values();
	}

}
