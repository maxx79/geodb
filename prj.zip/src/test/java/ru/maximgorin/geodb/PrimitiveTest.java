package ru.maximgorin.geodb;

import java.nio.charset.Charset;

import org.junit.Test;

import junit.framework.Assert;
import ru.maximgorin.geodb.primitive.Point;
import ru.maximgorin.geodb.primitive.Shape;

public class PrimitiveTest {
	@Test
	public void pointTest() {
		Point pt = new Point();
		Assert.assertEquals(0, pt.getX());
		Assert.assertEquals(0, pt.getY());
		pt.setX(5);
		pt.setY(5);
		Assert.assertEquals(5, pt.getX());
		Assert.assertEquals(5, pt.getY());
	}

	@Test
	public void shapeTest() {
		Shape shape = new Shape();
		Assert.assertEquals(0, shape.getPointCount());
		Point pt = new Point(1, 1);
		shape.add(pt);
		Assert.assertEquals(1, shape.getPointCount());
		shape.remove(pt);
		Assert.assertEquals(0, shape.getPointCount());
	}
}
